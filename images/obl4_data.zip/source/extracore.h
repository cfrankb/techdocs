// extracore.h : header file
//

#ifndef _EXTRACORE_H
#define _EXTRACORE_H

/////////////////////////////////////////////////////////////////////////////
class CExtraCore 
{
// Construction
public:
	CExtraCore();

// Attributes
public:

// Operations
public:

// Implementation
public:
	~CExtraCore();

	// Generated message map functions
protected:
};

#endif

/////////////////////////////////////////////////////////////////////////////
