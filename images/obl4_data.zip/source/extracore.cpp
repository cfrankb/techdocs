// extracore.cpp : implementation file
//

#include "stdafx.h"
#include "extracore.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExtraCore

CExtraCore::CExtraCore()
{
}

CExtraCore::~CExtraCore()
{
}


/////////////////////////////////////////////////////////////////////////////
// CExtraCore message handlers
